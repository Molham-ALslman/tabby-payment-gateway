<?php
/**
 * Tabby_Commission
 *
 * Adds Tabby cost-recovery fees to the cart/checkout dynamically:
 *   1. Percentage surcharge — using the gross-up formula so the merchant
 *      recovers the full Tabby service fee (not a simple flat add-on).
 *   2. Fixed per-transaction fee (e.g. AED 30).
 *
 * GROSS-UP MATH:
 *   Wrong  → add 7% flat   : 100 + 7    = 107  → Tabby takes 7% of 107 = 7.49 → merchant gets 99.51 ✗
 *   Correct → gross-up      : 100 × 0.07 / 0.93 = 7.53 → customer pays 107.53
 *             Tabby takes 7% of 107.53 = 7.53 → merchant gets exactly 100.00 ✓
 */
defined( 'ABSPATH' ) || exit;

class Tabby_Commission {

    public function __construct() {
        add_action( 'woocommerce_cart_calculate_fees',          [ $this, 'add_fees_to_cart' ] );
        add_action( 'woocommerce_checkout_before_order_review', [ $this, 'show_fee_notice' ] );
        add_action( 'wp_enqueue_scripts',                       [ $this, 'enqueue_scripts' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Retrieve the gateway settings safely
    // ─────────────────────────────────────────────────────────────────────────
    private function get_gateway() {
        static $gw = null;
        if ( $gw === null ) {
            $gateways = WC()->payment_gateways()->payment_gateways();
            $gw       = $gateways['tabby_custom'] ?? false;
        }
        return $gw;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Gross-Up calculation
    //  surcharge = base × rate / (1 − rate)
    // ─────────────────────────────────────────────────────────────────────────
    private function calc_surcharge( $base, $rate_pct, $grossup ) {
        if ( $rate_pct <= 0 ) return 0;
        $r = $rate_pct / 100;
        return $grossup === 'yes'
            ? round( $base * $r / ( 1 - $r ), 2 )   // gross-up (correct)
            : round( $base * $r, 2 );                // simple add-on (not recommended)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Add fees to the cart when Tabby is selected
    // ─────────────────────────────────────────────────────────────────────────
    public function add_fees_to_cart( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

        $chosen = WC()->session->get( 'chosen_payment_method' );
        if ( $chosen !== 'tabby_custom' ) return;

        $gw = $this->get_gateway();
        if ( ! $gw || ! $gw->is_available() ) return;

        $base = $cart->get_subtotal()
              + $cart->get_shipping_total()
              - $cart->get_discount_total();

        // Combine gross-up surcharge + fixed transaction fee into ONE line item
        $rate    = floatval( $gw->get_option( 'commission_rate', 0 ) );
        $grossup = $gw->get_option( 'commission_grossup', 'yes' );

        $surcharge = $this->calc_surcharge( $base, $rate, $grossup );

        $fixed = 0;
        if ( $gw->get_option( 'fixed_fee_enabled', 'yes' ) === 'yes' ) {
            $fixed = floatval( $gw->get_option( 'fixed_fee_amount', 0 ) );
        }

        $total = round( $surcharge + $fixed, 2 );
        if ( $total > 0 ) {
            $label = $gw->get_option( 'combined_fee_label', 'Premium Checkout Service' );
            $cart->add_fee( $label, $total, false );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Notice shown to the customer when Tabby is selected
    // ─────────────────────────────────────────────────────────────────────────
    public function show_fee_notice() {
        $gw = $this->get_gateway();
        if ( ! $gw ) return;
        if ( $gw->get_option( 'show_commission_notice' ) !== 'yes' ) return;

        $rate        = floatval( $gw->get_option( 'commission_rate', 0 ) );
        $grossup     = $gw->get_option( 'commission_grossup', 'yes' );
        $fixed       = floatval( $gw->get_option( 'fixed_fee_enabled', 'yes' ) === 'yes'
                        ? $gw->get_option( 'fixed_fee_amount', 0 ) : 0 );

        // Calculate combined total for the notice
        $r          = $rate / 100;
        $surcharge  = ( $rate > 0 )
            ? ( $grossup === 'yes'
                ? round( $base_example = 100 * $r / ( 1 - $r ), 2 )
                : $rate )
            : 0;

        // Use a simple descriptive notice — exact amount varies per order
        $combined_label = $gw->get_option( 'combined_fee_label', 'Premium Checkout Service' );
        $has_pct        = $rate > 0;
        $has_fixed      = $fixed > 0;

        if ( ! $has_pct && ! $has_fixed ) return;

        $parts = [];
        if ( $has_pct ) {
            $effective_pct = $grossup === 'yes'
                ? round( $r / ( 1 - $r ) * 100, 2 )
                : $rate;
            $parts[] = esc_html( $effective_pct ) . '% of subtotal';
        }
        if ( $has_fixed ) {
            $parts[] = wc_price( $fixed ) . ' flat fee';
        }
        ?>
        <div id="tabby-commission-notice" style="display:none; background:#fff8e1; border:1px solid #ffc107; border-radius:6px; padding:12px 16px; margin-bottom:16px; font-size:14px; line-height:1.8;">
            <strong>&#9432; Notice:</strong>
            A <strong><?php echo esc_html( $combined_label ); ?></strong> will be added to your order
            (<?php echo implode( ' + ', $parts ); ?>).
        </div>
        <?php
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  JS: show/hide notice + trigger order total refresh on payment change
    // ─────────────────────────────────────────────────────────────────────────
    public function enqueue_scripts() {
        if ( ! is_checkout() ) return;

        $gw = $this->get_gateway();
        if ( ! $gw ) return;

        $rate  = floatval( $gw->get_option( 'commission_rate', 0 ) );
        $fixed = floatval( $gw->get_option( 'fixed_fee_amount', 0 ) );
        if ( $rate <= 0 && $fixed <= 0 ) return;

        wp_add_inline_script( 'jquery', "
            jQuery(function($){
                function toggleTabbyNotice(){
                    var m = $('input[name=\"payment_method\"]:checked').val();
                    if( m === 'tabby_custom' ){
                        $('#tabby-commission-notice').slideDown(250);
                    } else {
                        $('#tabby-commission-notice').slideUp(250);
                    }
                }
                $(document.body).on('change', 'input[name=\"payment_method\"]', function(){
                    toggleTabbyNotice();
                    $(document.body).trigger('update_checkout');
                });
                $(document.body).on('updated_checkout', function(){
                    toggleTabbyNotice();
                });
                toggleTabbyNotice();
            });
        " );
    }
}
