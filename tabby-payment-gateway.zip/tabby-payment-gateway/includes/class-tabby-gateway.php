<?php
/**
 * WC_Tabby_Custom_Gateway — Tabby Payment Gateway
 * Webhook logic aligned with https://docs.tabby.ai/pay-in-4-custom-integration/webhooks
 */
defined( 'ABSPATH' ) || exit;

class WC_Tabby_Custom_Gateway extends WC_Payment_Gateway {

    public $merchant_public_key;
    public $merchant_secret_key;
    public $merchant_code;
    public $environment;
    public $commission_rate;
    public $api_base;

    // Tabby server IPs — only accept webhooks from these
    // Source: https://docs.tabby.ai/pay-in-4-custom-integration/webhooks
    private $tabby_ips = [
        '34.166.36.90',
        '34.166.35.211',
        '34.166.34.222',
        '34.166.37.207',
        '34.93.76.191',
        '34.166.128.182',
        '34.166.170.3',
        '34.166.249.7',
    ];

    public function __construct() {
        $this->id                 = 'tabby_custom';
        $this->has_fields         = false;
        $this->method_title       = 'Tabby - Buy Now, Pay Later';
        $this->method_description = 'Split purchases into 4 interest-free installments with Tabby. Available in Saudi Arabia, UAE, Kuwait, Bahrain, Egypt and Qatar.';
        $this->supports           = [ 'products', 'refunds' ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title               = $this->get_option( 'title' );
        $this->description         = $this->get_option( 'description' );
        $this->merchant_public_key = $this->get_option( 'merchant_public_key' );
        $this->merchant_secret_key = $this->get_option( 'merchant_secret_key' );
        $this->merchant_code       = $this->get_option( 'merchant_code', 'default' );
        $this->environment         = $this->get_option( 'environment', 'sandbox' );
        $this->commission_rate     = floatval( $this->get_option( 'commission_rate', 0 ) );
        $this->api_base            = 'https://api.tabby.ai/api/v2';

        // Icon: uploaded logo or built-in SVG
        $custom_logo = $this->get_option( 'gateway_logo_url' );
        $this->icon  = ! empty( $custom_logo ) ? esc_url( $custom_logo ) : TABBY_CUSTOM_URL . 'assets/tabby-logo.svg';

        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'handle_logo_upload' ] );
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'maybe_register_webhook' ] );

        // Webhook endpoint: https://yourdomain.com/wc-api/tabby_custom_webhook
        add_action( 'woocommerce_api_tabby_custom_webhook', [ $this, 'handle_webhook' ] );

        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SETTINGS FIELDS
    // ─────────────────────────────────────────────────────────────────────────

    public function init_form_fields() {
        $this->form_fields = [

            // General
            'enabled' => [
                'title'   => 'Enable / Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable Tabby Payment Gateway',
                'default' => 'no',
            ],
            'title' => [
                'title'       => 'Payment Method Title',
                'type'        => 'text',
                'description' => 'The title customers see on the Checkout page.',
                'default'     => 'Pay Later with Tabby',
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => 'Payment Method Description',
                'type'        => 'textarea',
                'description' => 'Short description shown beneath the payment method on Checkout.',
                'default'     => 'Split your order into 4 interest-free installments — no hidden fees. Available for Saudi Arabia, UAE, Kuwait, Bahrain, Egypt and Qatar.',
            ],

            // Logo
            'logo_section' => [
                'title'       => 'Gateway Logo',
                'type'        => 'title',
                'description' => 'Upload a custom logo displayed next to Tabby on the Checkout page. Recommended: 120 × 40 px, PNG or SVG with a transparent background.',
            ],
            'gateway_logo_url' => [
                'title'       => 'Logo URL',
                'type'        => 'text',
                'description' => 'Direct URL of the logo image. Paste a URL here or use the Upload field below.',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'gateway_logo_upload' => [
                'title'       => 'Upload Logo File',
                'type'        => 'gateway_logo_upload',
                'description' => 'Choose an image file from your computer, then click "Save changes".',
            ],
            'logo_max_height' => [
                'title'             => 'Logo Max Height (px)',
                'type'              => 'number',
                'description'       => 'Maximum display height of the logo on Checkout. Default: 36 px.',
                'default'           => '36',
                'custom_attributes' => [ 'min' => '16', 'max' => '120', 'step' => '1' ],
                'desc_tip'          => true,
            ],

            // API Keys
            'api_keys_section' => [
                'title' => 'API Keys',
                'type'  => 'title',
            ],
            'environment' => [
                'title'       => 'Environment',
                'type'        => 'select',
                'description' => 'Select "Sandbox" while testing, then switch to "Production" when going live.',
                'options'     => [
                    'sandbox'    => 'Sandbox (Testing)',
                    'production' => 'Production (Live)',
                ],
                'default'  => 'sandbox',
                'desc_tip' => true,
            ],
            'merchant_public_key' => [
                'title'       => 'Public API Key',
                'type'        => 'text',
                'description' => 'Starts with "pk_". Found in Tabby Merchant Portal → Settings → API Keys.',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'merchant_secret_key' => [
                'title'       => 'Secret API Key',
                'type'        => 'password',
                'description' => 'Starts with "sk_". Found in Tabby Merchant Portal → Settings → API Keys. Keep this private.',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'merchant_code' => [
                'title'       => 'Merchant Code',
                'type'        => 'text',
                'description' => 'Found in Tabby Merchant Portal → Settings → API Keys. Usually "default" for single-country stores. Used as the X-Merchant-Code header in all API requests.',
                'default'     => 'default',
                'desc_tip'    => true,
            ],

            // Webhook
            'webhook_section' => [
                'title'       => 'Webhook Settings',
                'type'        => 'title',
                'description' => 'Tabby sends payment status notifications to your webhook URL. Click "Save changes" to register the webhook automatically with Tabby.',
            ],
            'webhook_url_display' => [
                'title'             => 'Webhook Endpoint URL',
                'type'              => 'text',
                'description'       => 'Your webhook URL — registered automatically with Tabby when you save settings.',
                'default'           => home_url( '/wc-api/tabby_custom_webhook' ),
                'custom_attributes' => [ 'readonly' => 'readonly' ],
            ],
            'webhook_auth_header_title' => [
                'title'       => 'Webhook Auth Header Name (optional)',
                'type'        => 'text',
                'description' => 'An arbitrary header name Tabby will send with every webhook so you can verify it came from them. Example: "X-Tabby-Signature".',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'webhook_auth_header_value' => [
                'title'       => 'Webhook Auth Header Value (optional)',
                'type'        => 'text',
                'description' => 'The value Tabby will send in the header named above. Use a long random string.',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'webhook_ip_check' => [
                'title'   => 'IP Whitelist Verification',
                'type'    => 'checkbox',
                'label'   => 'Only accept webhooks from known Tabby server IP addresses (recommended)',
                'default' => 'yes',
            ],
            'webhook_registered' => [
                'title'             => 'Webhook Registration Status',
                'type'              => 'text',
                'description'       => 'Updated automatically each time you save settings.',
                'default'           => 'Not registered yet — save settings to register.',
                'custom_attributes' => [ 'readonly' => 'readonly' ],
            ],
            'webhook_id' => [
                'title'             => 'Tabby Webhook ID',
                'type'              => 'text',
                'description'       => 'Assigned by Tabby after successful registration. Used for updates or deletion.',
                'default'           => '',
                'custom_attributes' => [ 'readonly' => 'readonly' ],
            ],

            // Commission
            'commission_section' => [
                'title' => 'Tabby Cost Recovery Settings',
                'type'  => 'title',
                'description' => '<div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px 16px;margin-top:6px;font-size:13px;line-height:1.7;">'
                    . '<strong>⚠️ Important — How the math works:</strong><br>'
                    . 'Tabby charges you a <strong>% service fee on the gross amount they receive</strong>, not on your net price.<br>'
                    . 'Simply adding 7% on top of your price is <strong>wrong</strong> and still results in a loss.<br>'
                    . '<strong>Correct formula (Gross-Up):</strong> Surcharge = Original Price × Rate ÷ (1 − Rate)<br>'
                    . 'Example: AED 100 product → surcharge = 100 × 0.07 ÷ 0.93 = <strong>AED 7.53</strong> (not 7.00)<br>'
                    . 'This plugin applies the gross-up formula automatically when "Gross-Up Mode" is enabled.'
                    . '</div>',
            ],

            // — Percentage fee (gross-up) —
            'commission_rate' => [
                'title'             => 'Tabby Service Fee Rate (%)',
                'type'              => 'number',
                'description'       => 'The percentage Tabby charges you (e.g. 7 for 7%). The plugin will gross-up this amount so after Tabby deducts their fee you receive exactly your original price. Set to 0 to disable.',
                'default'           => '7',
                'custom_attributes' => [ 'min' => '0', 'max' => '30', 'step' => '0.01' ],
                'desc_tip'          => true,
            ],
            'commission_grossup' => [
                'title'   => 'Gross-Up Mode (Recommended)',
                'type'    => 'checkbox',
                'label'   => 'Use gross-up formula so you recover the full fee — not just a flat add-on (Example: 7% fee → add 7.53%, not 7%)',
                'default' => 'yes',
            ],
            'combined_fee_label' => [
                'title'       => 'Fee Label (shown to customer)',
                'type'        => 'text',
                'description' => 'The single label shown to the customer covering both the % surcharge and the fixed fee combined.',
                'default'     => 'Premium Checkout Service',
                'desc_tip'    => true,
            ],

            // — Fixed transaction fee —
            'fixed_fee_enabled' => [
                'title'   => 'Fixed Transaction Fee',
                'type'    => 'checkbox',
                'label'   => 'Include the fixed per-transaction fee charged by Tabby (e.g. AED 30) in the combined total',
                'default' => 'yes',
            ],
            'fixed_fee_amount' => [
                'title'             => 'Fixed Fee Amount',
                'type'              => 'number',
                'description'       => 'The fixed amount Tabby deducts per transaction (e.g. 30 for AED 30). Added to the % surcharge and shown as one combined line.',
                'default'           => '30',
                'custom_attributes' => [ 'min' => '0', 'max' => '500', 'step' => '0.01' ],
                'desc_tip'          => true,
            ],

            // — Notice —
            'show_commission_notice' => [
                'title'   => 'Show Fee Notice at Checkout',
                'type'    => 'checkbox',
                'label'   => 'Display a notice to the customer explaining the fees when Tabby is selected',
                'default' => 'yes',
            ],

            // Advanced
            'advanced_section' => [
                'title' => 'Advanced Settings',
                'type'  => 'title',
            ],
            'debug' => [
                'title'   => 'Debug Log',
                'type'    => 'checkbox',
                'label'   => 'Enable logging to help troubleshoot issues (WooCommerce → Status → Logs → tabby-custom)',
                'default' => 'no',
            ],
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  LOGO UPLOAD — custom field renderer
    // ─────────────────────────────────────────────────────────────────────────

    public function generate_gateway_logo_upload_html( $key, $data ) {
        $current_url = $this->get_option( 'gateway_logo_url' );
        $field_key   = $this->get_field_key( $key );
        ob_start();
        ?>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label><?php echo esc_html( $data['title'] ); ?></label>
            </th>
            <td class="forminp">
                <?php if ( ! empty( $current_url ) ) : ?>
                    <div style="margin-bottom:12px; padding:10px; background:#f9f9f9; border:1px solid #e2e2e2; border-radius:6px; display:inline-block;">
                        <p style="margin:0 0 6px; font-weight:600; font-size:12px; color:#555; text-transform:uppercase; letter-spacing:.5px;">Current Logo Preview</p>
                        <img src="<?php echo esc_url( $current_url ); ?>" alt="Logo Preview" style="max-height:60px; display:block; margin-bottom:8px;">
                        <label style="display:inline-flex; align-items:center; gap:6px; cursor:pointer; font-size:13px; color:#c0392b;">
                            <input type="checkbox" name="<?php echo esc_attr( $field_key ); ?>_remove" value="1">
                            Remove current logo and use default
                        </label>
                    </div>
                <?php endif; ?>
                <div style="margin-top:8px;">
                    <input type="file" name="<?php echo esc_attr( $field_key ); ?>_file"
                           id="<?php echo esc_attr( $field_key ); ?>_file"
                           accept="image/png,image/svg+xml,image/jpeg,image/gif,image/webp"
                           style="display:block; margin-bottom:8px;">
                    <p class="description">
                        <?php echo esc_html( $data['description'] ); ?><br>
                        <strong>Accepted formats:</strong> PNG, SVG, JPG, GIF, WebP &nbsp;&bull;&nbsp;
                        <strong>Max file size:</strong> 2 MB &nbsp;&bull;&nbsp;
                        <strong>Recommended:</strong> 120 &times; 40 px, transparent background
                    </p>
                </div>
            </td>
        </tr>
        <?php
        return ob_get_clean();
    }

    public function handle_logo_upload() {
        $field_key = $this->get_field_key( 'gateway_logo_upload' );
        if ( ! empty( $_POST[ $field_key . '_remove' ] ) ) {
            $this->update_option( 'gateway_logo_url', '' );
            return;
        }
        if ( empty( $_FILES[ $field_key . '_file' ]['name'] ) ) return;

        if ( $_FILES[ $field_key . '_file' ]['size'] > 2 * 1024 * 1024 ) {
            WC_Admin_Settings::add_error( 'Tabby Logo Error: File size exceeds 2 MB. Please upload a smaller image.' );
            return;
        }
        $allowed = [ 'image/png', 'image/svg+xml', 'image/jpeg', 'image/gif', 'image/webp' ];
        $finfo   = new finfo( FILEINFO_MIME_TYPE );
        $mime    = $finfo->file( $_FILES[ $field_key . '_file' ]['tmp_name'] );
        if ( ! in_array( $mime, $allowed, true ) ) {
            WC_Admin_Settings::add_error( 'Tabby Logo Error: Invalid file type "' . esc_html( $mime ) . '". Accepted: PNG, SVG, JPG, GIF, WebP.' );
            return;
        }
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }
        $attachment_id = media_handle_upload( $field_key . '_file', 0 );
        if ( is_wp_error( $attachment_id ) ) {
            WC_Admin_Settings::add_error( 'Tabby Logo Upload Failed: ' . $attachment_id->get_error_message() );
            return;
        }
        $this->update_option( 'gateway_logo_url', wp_get_attachment_url( $attachment_id ) );
        WC_Admin_Settings::add_message( 'Tabby logo uploaded and saved successfully.' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  WEBHOOK REGISTRATION
    //  Docs: https://docs.tabby.ai/pay-in-4-custom-integration/webhooks
    //  "Registration should be done only once for one store country"
    // ─────────────────────────────────────────────────────────────────────────

    public function maybe_register_webhook() {
        if ( empty( $this->merchant_secret_key ) || empty( $this->merchant_public_key ) ) return;

        $webhook_url = home_url( '/wc-api/tabby_custom_webhook' );

        // Build body — only url + optional header object
        // Docs: https://docs.tabby.ai/api-reference/webhooks/register-a-webhook
        $body = [ 'url' => $webhook_url ];

        $auth_header_title = $this->get_option( 'webhook_auth_header_title', '' );
        $auth_header_value = $this->get_option( 'webhook_auth_header_value', '' );
        if ( ! empty( $auth_header_title ) && ! empty( $auth_header_value ) ) {
            $body['header'] = [
                'title' => $auth_header_title,
                'value' => $auth_header_value,
            ];
        }

        // CORRECT: endpoint is /api/v1/webhooks (NOT v2)
        // CORRECT: merchant_code goes as X-Merchant-Code HEADER (NOT in body)
        $response = wp_remote_post(
            'https://api.tabby.ai/api/v1/webhooks',
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $this->merchant_secret_key,
                    'Content-Type'   => 'application/json',
                    'Accept'         => 'application/json',
                    'X-Merchant-Code' => $this->merchant_code,
                ],
                'body' => wp_json_encode( $body ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            $msg = $response->get_error_message();
            $this->update_option( 'webhook_registered', 'Registration failed: ' . $msg );
            WC_Admin_Settings::add_error( 'Tabby Webhook registration failed: ' . $msg );
            $this->log( 'Webhook registration WP_Error: ' . $msg );
            return;
        }

        $code  = wp_remote_retrieve_response_code( $response );
        $rbody = json_decode( wp_remote_retrieve_body( $response ), true );
        $this->log( 'Webhook registration HTTP ' . $code . ': ' . wp_json_encode( $rbody ) );

        if ( in_array( $code, [ 200, 201 ], true ) ) {
            $webhook_id = $rbody['id'] ?? 'n/a';
            $is_test    = $rbody['is_test'] ? 'Sandbox' : 'Production';
            $status     = 'Registered ✓ (' . $is_test . ') — Webhook ID: ' . $webhook_id . ' — ' . gmdate( 'Y-m-d H:i' ) . ' UTC';
            $this->update_option( 'webhook_registered', $status );
            // Store the webhook ID for future updates/deletions
            $this->update_option( 'webhook_id', $webhook_id );
            WC_Admin_Settings::add_message( 'Tabby Webhook registered successfully. ID: ' . $webhook_id );

        } elseif ( $code === 409 ) {
            // 409 Conflict = already registered — perfectly fine
            $this->update_option( 'webhook_registered', 'Already registered — no change needed.' );
            WC_Admin_Settings::add_message( 'Tabby Webhook is already registered with this URL.' );

        } else {
            $err = $rbody['error'] ?? ( $rbody['message'] ?? 'HTTP ' . $code );
            $this->update_option( 'webhook_registered', 'Failed (HTTP ' . $code . '): ' . $err );
            WC_Admin_Settings::add_error( 'Tabby Webhook registration failed (HTTP ' . $code . '): ' . esc_html( $err ) );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  WEBHOOK HANDLER
    //  Aligned with: https://docs.tabby.ai/pay-in-4-custom-integration/webhooks
    //
    //  Statuses arrive in LOWER CASE from webhooks: authorized, closed, rejected, expired
    //  (Upper case only from the Retrieve API)
    //
    //  Flow per docs:
    //  1. "authorized" → send Capture request → complete order
    //  2. "authorized" again (after capture) → idempotency: skip if already done
    //  3. "closed" → payment fully confirmed → no extra action needed
    // ─────────────────────────────────────────────────────────────────────────

    public function handle_webhook() {
        // 1. Verify request method
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
            wp_die( 'Method not allowed.', '', [ 'response' => 405 ] );
        }

        // 2. IP whitelist check (recommended by Tabby docs)
        if ( $this->get_option( 'webhook_ip_check', 'yes' ) === 'yes' ) {
            $client_ip = $this->get_client_ip();
            if ( ! in_array( $client_ip, $this->tabby_ips, true ) ) {
                $this->log( 'Webhook blocked: unknown IP ' . $client_ip );
                wp_die( 'Forbidden.', '', [ 'response' => 403 ] );
            }
        }

        // 3. Optional auth header verification
        // Docs: check the auth header to verify authenticity of the request
        $auth_header_title = $this->get_option( 'webhook_auth_header_title', '' );
        $auth_header_value = $this->get_option( 'webhook_auth_header_value', '' );
        if ( ! empty( $auth_header_title ) && ! empty( $auth_header_value ) ) {
            // Convert header name to PHP server variable format (e.g. X-Tabby-Sig → HTTP_X_TABBY_SIG)
            $server_key      = 'HTTP_' . strtoupper( str_replace( '-', '_', $auth_header_title ) );
            $received_value  = $_SERVER[ $server_key ] ?? '';
            if ( ! hash_equals( $auth_header_value, $received_value ) ) {
                $this->log( 'Webhook blocked: auth header mismatch for ' . $auth_header_title );
                wp_die( 'Unauthorized.', '', [ 'response' => 401 ] );
            }
        }

        // 4. Read and parse payload
        $raw     = file_get_contents( 'php://input' );
        $payload = json_decode( $raw, true );
        $this->log( 'Webhook received: ' . $raw );

        // 5. Validate required fields
        // Tabby webhook payload uses "id" (payment id) and "status"
        if ( empty( $payload['id'] ) || empty( $payload['status'] ) ) {
            $this->log( 'Webhook invalid: missing id or status.' );
            wp_die( 'Invalid payload.', '', [ 'response' => 400 ] );
        }

        $payment_id  = sanitize_text_field( $payload['id'] );
        // Docs: "order.reference_id" holds our WooCommerce order ID
        $order_ref   = $payload['order']['reference_id'] ?? '';
        $status      = strtolower( $payload['status'] ); // always lowercase from webhooks

        // 6. Locate WooCommerce order
        $order = null;

        // Try by stored Tabby payment ID first
        $orders = wc_get_orders( [
            'meta_key'   => '_tabby_payment_id',
            'meta_value' => $payment_id,
            'limit'      => 1,
        ] );
        if ( ! empty( $orders ) ) {
            $order = $orders[0];
        }

        // Fallback: use order reference_id sent in the payload
        if ( ! $order && ! empty( $order_ref ) ) {
            $order = wc_get_order( absint( $order_ref ) );
        }

        if ( ! $order ) {
            $this->log( 'Webhook: order not found for payment_id=' . $payment_id . ' ref=' . $order_ref );
            // Return 200 anyway so Tabby stops retrying for a missing order
            wp_die( 'Order not found — acknowledged.', '', [ 'response' => 200 ] );
        }

        // 7. Idempotency: skip if already fully processed
        // Docs: "configure the system to ignore multiple copies of the same notification"
        $processed_webhooks = (array) $order->get_meta( '_tabby_processed_webhooks' );

        $webhook_event_key = $payment_id . ':' . $status . ':' . ( $payload['captures'][0]['id'] ?? '' );
        if ( in_array( $webhook_event_key, $processed_webhooks, true ) ) {
            $this->log( 'Webhook duplicate — already processed: ' . $webhook_event_key );
            wp_die( 'OK (duplicate).', '', [ 'response' => 200 ] );
        }

        // 8. Store payment_id on order if not already set
        if ( ! $order->get_meta( '_tabby_payment_id' ) ) {
            $order->update_meta_data( '_tabby_payment_id', $payment_id );
        }

        // 9. Process based on status (lowercase per Tabby webhook docs)
        switch ( $status ) {

            case 'authorized':
                /*
                 * Docs step 1: First "authorized" webhook → send Capture Request.
                 * Docs step 2: Second "authorized" (post-capture) → ignore (idempotency).
                 * We detect which case this is by checking if a capture already exists.
                 */
                $has_capture = ! empty( $payload['captures'] );

                if ( ! $has_capture ) {
                    // First authorization — send capture
                    $capture_result = $this->send_capture_request( $payment_id, $payload['amount'] );
                    if ( $capture_result ) {
                        $order->update_status( 'processing', 'Tabby payment authorized. Capture request sent. Payment ID: ' . $payment_id );
                        $order->add_order_note( 'Tabby: Payment authorized. Capture sent. Payment ID: ' . $payment_id );
                    } else {
                        $order->add_order_note( 'Tabby: Payment authorized but capture request failed. Payment ID: ' . $payment_id . '. Please capture manually via Tabby Merchant Portal.' );
                        $this->log( 'Capture request failed for payment_id=' . $payment_id );
                    }
                } else {
                    // Second "authorized" webhook after capture — no action needed (per docs)
                    $capture_id = $payload['captures'][0]['id'] ?? 'n/a';
                    $order->add_order_note( 'Tabby: Capture confirmed. Capture ID: ' . $capture_id . '. No action required.' );
                    $this->log( 'Webhook: post-capture authorized notification — no action needed.' );
                }
                break;

            case 'closed':
                /*
                 * Docs step 3: "closed" = payment completed from both sides.
                 * Mark order complete. No further action required.
                 */
                if ( ! in_array( $order->get_status(), [ 'completed', 'processing' ], true ) ) {
                    $order->payment_complete( $payment_id );
                }
                $order->add_order_note( 'Tabby: Payment fully closed and confirmed. Payment ID: ' . $payment_id );
                break;

            case 'rejected':
                $order->update_status( 'failed', 'Tabby payment rejected. Payment ID: ' . $payment_id );
                $order->add_order_note( 'Tabby: Payment was rejected by Tabby. Payment ID: ' . $payment_id );
                break;

            case 'expired':
                // Optional event — must be requested from Tabby team per docs
                $order->update_status( 'cancelled', 'Tabby payment session expired. Payment ID: ' . $payment_id );
                $order->add_order_note( 'Tabby: Payment session expired. Payment ID: ' . $payment_id );
                break;

            default:
                $this->log( 'Webhook: unhandled status "' . $status . '" for payment_id=' . $payment_id );
        }

        // 10. Mark this webhook event as processed (idempotency)
        $processed_webhooks[] = $webhook_event_key;
        $order->update_meta_data( '_tabby_processed_webhooks', $processed_webhooks );
        $order->save();

        // 11. Respond with 200 immediately (docs: respond right away, process async)
        // Docs: "We timeout a webhook request after 1 minute and resend it up to 4 more times"
        wp_die( 'OK', '', [ 'response' => 200 ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  CAPTURE REQUEST
    //  Required per docs after receiving the first "authorized" webhook
    // ─────────────────────────────────────────────────────────────────────────

    private function send_capture_request( $payment_id, $amount ) {
        $response = wp_remote_post(
            $this->api_base . '/payments/' . $payment_id . '/captures',
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $this->merchant_secret_key,
                    'Content-Type'   => 'application/json',
                    'Accept'         => 'application/json',
                    'X-Merchant-Code' => $this->merchant_code,
                ],
                'body' => wp_json_encode( [ 'amount' => strval( $amount ) ] ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log( 'Capture WP_Error: ' . $response->get_error_message() );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $this->log( 'Capture response HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response ) );

        return in_array( $code, [ 200, 201 ], true );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PAYMENT PROCESSING
    // ─────────────────────────────────────────────────────────────────────────

    public function enqueue_scripts() {
        if ( ! is_checkout() ) return;
        wp_enqueue_script( 'tabby-promo', 'https://checkout.tabby.ai/tabby-promo.js', [], null, true );
        wp_enqueue_style( 'tabby-custom-style', TABBY_CUSTOM_URL . 'assets/css/tabby-checkout.css', [], TABBY_CUSTOM_VERSION );
        $max_height = absint( $this->get_option( 'logo_max_height', 36 ) );
        wp_add_inline_style( 'tabby-custom-style', '.payment_method_tabby_custom img { max-height:' . $max_height . 'px !important; width:auto; }' );
    }

    public function validate_api_keys() {
        if ( empty( $this->merchant_public_key ) || empty( $this->merchant_secret_key ) ) {
            $this->log( 'ERROR: Merchant API keys are not configured.' );
            return false;
        }
        return true;
    }

    public function process_payment( $order_id ) {
        $order = wc_get_order( $order_id );

        if ( ! $this->validate_api_keys() ) {
            wc_add_notice( 'Tabby payment gateway is not properly configured. Please contact the store owner.', 'error' );
            return [ 'result' => 'failure' ];
        }

        $commission = $this->calculate_commission( $order );
        if ( $commission > 0 ) $this->add_commission_fee( $order, $commission );

        $payload  = $this->build_payment_payload( $order );
        $response = $this->create_tabby_session( $payload );

        if ( is_wp_error( $response ) ) {
            $this->log( 'Payment session WP_Error: ' . $response->get_error_message() );
            wc_add_notice( 'Could not connect to Tabby. Please try again or choose another payment method.', 'error' );
            return [ 'result' => 'failure' ];
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $this->log( 'Tabby checkout API response: ' . wp_json_encode( $body ) );

        if ( empty( $body['status'] ) || $body['status'] === 'rejected' ) {
            $reason = $body['rejection_reason'] ?? 'unknown_error';
            wc_add_notice( 'Your Tabby request was not approved (reason: ' . esc_html( $reason ) . '). Please try another payment method.', 'error' );
            return [ 'result' => 'failure' ];
        }

        $payment_id = $body['payment']['id'] ?? '';
        if ( $payment_id ) {
            $order->update_meta_data( '_tabby_payment_id', $payment_id );
            $order->save();
        }

        $redirect_url =
            $body['configuration']['available_products']['installments'][0]['web_url'] ??
            $body['configuration']['available_products']['pay_later'][0]['web_url'] ??
            '';

        if ( empty( $redirect_url ) ) {
            wc_add_notice( 'Could not retrieve the Tabby payment link. Please try again.', 'error' );
            return [ 'result' => 'failure' ];
        }

        $order->update_status( 'pending', 'Awaiting Tabby payment confirmation.' );
        return [ 'result' => 'success', 'redirect' => $redirect_url ];
    }

    private function build_payment_payload( $order ) {
        $items = [];
        foreach ( $order->get_items() as $item ) {
            $product  = $item->get_product();
            $category = '';
            $cats     = get_the_terms( $product->get_id(), 'product_cat' );
            if ( $cats && ! is_wp_error( $cats ) ) $category = $cats[0]->name;

            $items[] = [
                'title'           => $item->get_name(),
                'quantity'        => $item->get_quantity(),
                'unit_price'      => strval( round( $item->get_total() / $item->get_quantity(), 2 ) ),
                'discount_amount' => '0.00',
                'reference_id'    => strval( $product->get_id() ),
                'image_url'       => get_the_post_thumbnail_url( $product->get_id(), 'thumbnail' ) ?: '',
                'product_url'     => get_permalink( $product->get_id() ),
                'category'        => $category,
            ];
        }

        $currency = get_woocommerce_currency();
        return [
            'payment' => [
                'amount'      => strval( $order->get_total() ),
                'currency'    => $currency,
                'description' => 'Order #' . $order->get_id(),
                'buyer'       => [
                    'phone' => $order->get_billing_phone(),
                    'email' => $order->get_billing_email(),
                    'name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
                    'dob'   => null,
                ],
                'shipping_address' => [
                    'city'    => $order->get_shipping_city() ?: $order->get_billing_city(),
                    'address' => $order->get_shipping_address_1() ?: $order->get_billing_address_1(),
                    'zip'     => $order->get_shipping_postcode() ?: $order->get_billing_postcode(),
                ],
                'order' => [
                    'tax_amount'      => strval( $order->get_total_tax() ),
                    'shipping_amount' => strval( $order->get_shipping_total() ),
                    'discount_amount' => strval( $order->get_discount_total() ),
                    'updated_at'      => gmdate( 'c' ),
                    'reference_id'    => strval( $order->get_id() ),
                    'items'           => $items,
                ],
                'buyer_history' => [
                    'registered_since' => gmdate( 'c', strtotime( '-1 year' ) ),
                    'loyalty_level'    => 0,
                ],
            ],
            'lang'          => 'en',
            'merchant_code' => $this->merchant_code,
            'merchant_urls' => [
                'success' => $this->get_return_url( $order ),
                'cancel'  => wc_get_checkout_url(),
                'failure' => wc_get_checkout_url(),
            ],
        ];
    }

    private function create_tabby_session( $payload ) {
        return wp_remote_post( $this->api_base . '/checkout', [
            'timeout' => 30,
            'headers' => [
                'Authorization'  => 'Bearer ' . $this->merchant_secret_key,
                'Content-Type'   => 'application/json',
                'Accept'         => 'application/json',
                'X-Merchant-Code' => $this->merchant_code,
            ],
            'body' => wp_json_encode( $payload ),
        ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  COST RECOVERY — Gross-Up formula + Fixed transaction fee
    //
    //  WHY GROSS-UP?
    //  Tabby charges X% on the amount THEY RECEIVE (the gross amount).
    //  If you simply add X% on top of your price, you still lose money:
    //    e.g. item = 100, you add 7 → customer pays 107 → Tabby takes 7% of 107 = 7.49 → you get 99.51 ✗
    //
    //  Gross-Up formula:  surcharge = price × rate / (1 − rate)
    //    e.g. item = 100, surcharge = 100 × 0.07 / 0.93 = 7.53 → customer pays 107.53
    //         Tabby takes 7% of 107.53 = 7.53 → you get exactly 100.00 ✓
    //
    //  Fixed fee (e.g. AED 30) is added separately on top — it's passed through 1:1.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Calculate the percentage surcharge using the correct gross-up formula.
     * Returns 0 if the rate is not configured.
     */
    public function calculate_commission( $order ) {
        $rate = floatval( $this->commission_rate );
        if ( $rate <= 0 ) return 0;

        // Base = subtotal + shipping − discounts (excludes taxes if applicable)
        $base = $order->get_subtotal()
              + $order->get_shipping_total()
              - $order->get_discount_total();

        $grossup = $this->get_option( 'commission_grossup', 'yes' );

        if ( $grossup === 'yes' ) {
            // Gross-up: recover full fee so net = original price
            // surcharge = base × rate / (1 − rate)
            $rate_decimal = $rate / 100;
            $surcharge    = $base * $rate_decimal / ( 1 - $rate_decimal );
        } else {
            // Simple add-on (not recommended — results in slight under-recovery)
            $surcharge = $base * ( $rate / 100 );
        }

        return round( $surcharge, 2 );
    }

    /**
     * Calculate the fixed per-transaction fee.
     */
    public function calculate_fixed_fee() {
        if ( $this->get_option( 'fixed_fee_enabled', 'yes' ) !== 'yes' ) return 0;
        return round( floatval( $this->get_option( 'fixed_fee_amount', 0 ) ), 2 );
    }

    /**
     * Add a SINGLE combined fee line "Premium Checkout Service"
     * = gross-up surcharge (7%) + fixed transaction fee (AED 30) merged into one amount.
     */
    private function add_commission_fee( $order, $surcharge_amount ) {
        $fixed = $this->calculate_fixed_fee();
        $total = round( $surcharge_amount + $fixed, 2 );

        if ( $total <= 0 ) return;

        $label = $this->get_option( 'combined_fee_label', 'Premium Checkout Service' );

        $fee = new WC_Order_Item_Fee();
        $fee->set_name( $label );
        $fee->set_amount( $total );
        $fee->set_total( $total );
        $fee->set_tax_status( 'none' );
        $order->add_item( $fee );

        $this->log( sprintf(
            'Combined fee — label: "%s" | surcharge: %.2f | fixed: %.2f | total: %.2f %s',
            $label, $surcharge_amount, $fixed, $total, get_woocommerce_currency()
        ) );

        $order->calculate_totals();
        $order->save();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  REFUND
    // ─────────────────────────────────────────────────────────────────────────

    public function process_refund( $order_id, $amount = null, $reason = '' ) {
        $order      = wc_get_order( $order_id );
        $payment_id = $order->get_meta( '_tabby_payment_id' );
        if ( ! $payment_id ) return new WP_Error( 'tabby_refund', 'No Tabby Payment ID found for this order.' );

        $response = wp_remote_post( $this->api_base . '/payments/' . $payment_id . '/refunds', [
            'timeout' => 30,
            'headers' => [
                'Authorization'  => 'Bearer ' . $this->merchant_secret_key,
                'Content-Type'   => 'application/json',
                'X-Merchant-Code' => $this->merchant_code,
            ],
            'body' => wp_json_encode( [
                'amount' => strval( $amount ),
                'reason' => $reason ?: 'Merchant-initiated refund',
            ] ),
        ] );

        if ( is_wp_error( $response ) ) return $response;

        $code = wp_remote_retrieve_response_code( $response );
        if ( in_array( $code, [ 200, 201 ], true ) ) {
            $order->add_order_note( 'Refund of ' . wc_price( $amount ) . ' processed via Tabby.' );
            return true;
        }
        return new WP_Error( 'tabby_refund_failed', 'Refund failed. Tabby API returned HTTP ' . $code . '.' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Get real client IP (handles proxies) */
    private function get_client_ip() {
        $keys = [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ];
        foreach ( $keys as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = trim( explode( ',', $_SERVER[ $key ] )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
            }
        }
        return '';
    }

    private function log( $message ) {
        if ( $this->get_option( 'debug' ) !== 'yes' ) return;
        wc_get_logger()->info( $message, [ 'source' => 'tabby-custom' ] );
    }
}
