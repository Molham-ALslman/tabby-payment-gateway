# Tabby Payment Gateway Custom — WordPress Plugin

A custom WooCommerce payment gateway for **Tabby** (Buy Now, Pay Later) with configurable commission fees and logo upload support.

---

## Features

- ✅ Tabby BNPL checkout (4 interest-free installments)
- ✅ Custom logo upload (PNG, SVG, JPG, GIF, WebP)
- ✅ Adjustable logo max-height
- ✅ Global commission rate (%) added automatically when Tabby is selected
- ✅ Per-product commission override
- ✅ Customer notice shown when Tabby is selected
- ✅ Full refund support from WooCommerce admin
- ✅ Webhook handler for automatic order status updates
- ✅ Debug log integration (WooCommerce → Status → Logs)
- ✅ Tabby Reports page with revenue & commission totals

---

## Installation

1. Upload the `tabby-payment-gateway` folder to `/wp-content/plugins/`  
   **or** go to **Plugins → Add New → Upload Plugin** and upload the `.zip` file.
2. Activate the plugin from **Plugins**.
3. Go to **WooCommerce → Settings → Payments → Tabby Custom → Manage**.
4. Enter your **Merchant Public Key** and **Merchant Secret Key**.
5. Set Environment to **Production** when ready to go live.
6. (Optional) Upload your custom logo and set a commission rate.
7. **Save changes**.

---

## Getting Your API Keys

1. Log in to [https://merchants.tabby.ai](https://merchants.tabby.ai)
2. Go to **Settings → API Keys**
3. Copy both the **Public Key** and the **Secret Key**

> For sandbox/testing keys, email **partner@tabby.ai** or **partner@tabby.sa**

---

## Webhook Setup

Add the following URL in your **Tabby Merchant Portal → Settings → Webhooks**:

```
https://yourdomain.com/wc-api/tabby_custom_webhook
```

This allows Tabby to automatically update your order status when a payment is approved, rejected, or expires.

---

## Logo Upload

Navigate to **WooCommerce → Settings → Payments → Tabby Custom → Manage**:

| Setting | Details |
|---------|---------|
| **Logo URL** | Paste a direct image URL, or leave blank and use the upload field |
| **Upload Logo File** | Click "Choose File", select your image, then click "Save changes" |
| **Logo Max Height** | Controls display height on Checkout (default: 36 px) |
| **Remove Logo** | Tick the checkbox next to the current logo preview |

**Accepted formats:** PNG, SVG, JPG, GIF, WebP — max **2 MB** — recommended size **120 × 40 px** with transparent background.

---

## Commission Settings

| Setting | Description |
|---------|-------------|
| **Commission Rate (%)** | Applied to subtotal + shipping − discount. E.g. `2.5` = 2.5% |
| **Commission Fee Label** | Label shown in the customer's order summary, e.g. "Tabby Service Fee" |
| **Show Commission Notice** | Displays a notice to the customer when they select Tabby |

### Per-product override

On any product edit screen → **Tabby tab**:
- **Override commission** — enable to use a product-specific rate
- **Product Commission Rate (%)** — the custom rate for this product
- **Exclude from Tabby** — hides Tabby as a payment option for orders containing this product

---

## Supported Currencies & Countries

| Currency | Country |
|----------|---------|
| SAR | Saudi Arabia |
| AED | United Arab Emirates |
| KWD | Kuwait |
| BHD | Bahrain |
| EGP | Egypt |
| QAR | Qatar |

---

## Troubleshooting

| Problem | Solution |
|---------|---------|
| Tabby not showing at checkout | Confirm the plugin is enabled under **WooCommerce → Settings → Payments** |
| API keys error | Make sure you are using the correct keys for the selected environment |
| Sandbox payments not completing | This is expected — test keys allow session creation but not full payment |
| Logo not showing | Ensure the URL is publicly accessible and the file is under 2 MB |
| Commission not applied | Check that the rate is > 0 and the customer has selected Tabby |

---

## Changelog

### 1.0.0
- Initial release
- Full English interface
- Logo upload with WordPress Media Library integration
- Commission fee system (global + per-product)
- Webhook support
- Refund support
- Tabby Reports admin page
