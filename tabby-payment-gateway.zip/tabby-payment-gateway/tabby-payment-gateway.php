<?php
/**
 * Plugin Name: Tabby Payment Gateway Custom
 * Plugin URI:  https://tabby.ai
 * Description: Custom Tabby (Buy Now, Pay Later) payment gateway for WooCommerce with configurable commission fees.
 * Version:     1.0.0
 * Author:      Custom Development ( Molham + Ai )
 * Text Domain: tabby-custom
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 */

defined( 'ABSPATH' ) || exit;

define( 'TABBY_CUSTOM_VERSION', '1.0.0' );
define( 'TABBY_CUSTOM_PATH',    plugin_dir_path( __FILE__ ) );
define( 'TABBY_CUSTOM_URL',     plugin_dir_url( __FILE__ ) );

/** Check WooCommerce is active */
function tabby_custom_check_woocommerce() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p><strong>Tabby Custom:</strong> This plugin requires WooCommerce to be installed and active.</p></div>';
        } );
        deactivate_plugins( plugin_basename( __FILE__ ) );
    }
}
add_action( 'admin_init', 'tabby_custom_check_woocommerce' );

/** Initialise gateway after WooCommerce loads */
add_action( 'plugins_loaded', 'tabby_custom_init_gateway' );
function tabby_custom_init_gateway() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

    require_once TABBY_CUSTOM_PATH . 'includes/class-tabby-gateway.php';
    require_once TABBY_CUSTOM_PATH . 'includes/class-tabby-commission.php';
    require_once TABBY_CUSTOM_PATH . 'admin/class-tabby-admin.php';

    // Register gateway with WooCommerce
    add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
        $gateways[] = 'WC_Tabby_Custom_Gateway';
        return $gateways;
    } );

    new Tabby_Commission();
    new Tabby_Admin_Settings();
}

/** Add Settings link on the Plugins page */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
    $settings_link = '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=tabby_custom' ) . '">Settings</a>';
    array_unshift( $links, $settings_link );
    return $links;
} );
