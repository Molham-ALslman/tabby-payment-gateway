<?php
/**
 * Tabby_Admin_Settings - Per-product commission overrides and admin reports
 */
defined( 'ABSPATH' ) || exit;

class Tabby_Admin_Settings {

    public function __construct() {
        add_filter( 'woocommerce_product_data_tabs',    [ $this, 'add_tabby_product_tab' ] );
        add_action( 'woocommerce_product_data_panels',  [ $this, 'render_tabby_product_panel' ] );
        add_action( 'woocommerce_process_product_meta', [ $this, 'save_tabby_product_meta' ] );

        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );

        add_filter( 'manage_woocommerce_page_wc-orders_columns',        [ $this, 'add_orders_column' ] );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column',   [ $this, 'render_orders_column' ], 10, 2 );
    }

    /** Add Tabby tab to product edit screen */
    public function add_tabby_product_tab( $tabs ) {
        $tabs['tabby_commission'] = [
            'label'    => 'Tabby',
            'target'   => 'tabby_commission_data',
            'class'    => [],
            'priority' => 80,
        ];
        return $tabs;
    }

    /** Render the Tabby product panel */
    public function render_tabby_product_panel() {
        global $post;
        $gateways    = WC()->payment_gateways()->payment_gateways();
        $gateway     = $gateways['tabby_custom'] ?? null;
        $global_rate = $gateway ? $gateway->get_option( 'commission_rate', 0 ) : 0;

        echo '<div id="tabby_commission_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        woocommerce_wp_checkbox( [
            'id'          => '_tabby_override_commission',
            'label'       => 'Override Tabby commission for this product',
            'description' => 'Enable to set a custom commission rate for this specific product, overriding the global setting.',
        ] );

        woocommerce_wp_text_input( [
            'id'                => '_tabby_product_commission',
            'label'             => 'Product Commission Rate (%)',
            'description'       => 'Example: 3 means 3% of this product\'s price. Leave blank to use the global rate.',
            'type'              => 'number',
            'custom_attributes' => [ 'min' => '0', 'max' => '20', 'step' => '0.01' ],
            'data_type'         => 'decimal',
            'desc_tip'          => true,
        ] );

        woocommerce_wp_checkbox( [
            'id'          => '_tabby_excluded',
            'label'       => 'Exclude this product from Tabby',
            'description' => 'When enabled, Tabby will not be available as a payment method for orders containing this product.',
        ] );

        echo '</div><div class="options_group">';
        echo '<p class="form-field"><em>Global Tabby commission rate: <strong>' . esc_html( $global_rate ) . '%</strong></em></p>';
        echo '</div></div>';
    }

    /** Save Tabby product meta */
    public function save_tabby_product_meta( $product_id ) {
        update_post_meta( $product_id, '_tabby_override_commission', isset( $_POST['_tabby_override_commission'] ) ? 'yes' : 'no' );
        update_post_meta( $product_id, '_tabby_product_commission',  sanitize_text_field( $_POST['_tabby_product_commission'] ?? '' ) );
        update_post_meta( $product_id, '_tabby_excluded',            isset( $_POST['_tabby_excluded'] ) ? 'yes' : 'no' );
    }

    /** Add Tabby Reports submenu */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Tabby Reports',
            'Tabby Reports',
            'manage_woocommerce',
            'tabby-custom-reports',
            [ $this, 'render_reports_page' ]
        );
    }

    /** Render the Tabby Reports page */
    public function render_reports_page() {
        $orders = wc_get_orders( [
            'payment_method' => 'tabby_custom',
            'status'         => [ 'wc-completed', 'wc-processing' ],
            'limit'          => -1,
        ] );

        $total_revenue    = 0;
        $total_commission = 0;

        foreach ( $orders as $order ) {
            $total_revenue += $order->get_total();
            foreach ( $order->get_fees() as $fee ) {
                if ( stripos( $fee->get_name(), 'tabby' ) !== false ) {
                    $total_commission += $fee->get_total();
                }
            }
        }
        ?>
        <div class="wrap">
            <h1>&#128202; Tabby Reports</h1>

            <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin:20px 0;">

                <div style="background:#fff; border:1px solid #ddd; border-radius:8px; padding:24px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,.06);">
                    <h2 style="margin:0; color:#00A660; font-size:40px;"><?php echo count( $orders ); ?></h2>
                    <p style="margin:6px 0 0; color:#555; font-size:13px; text-transform:uppercase; letter-spacing:.5px;">Total Orders via Tabby</p>
                </div>

                <div style="background:#fff; border:1px solid #ddd; border-radius:8px; padding:24px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,.06);">
                    <h2 style="margin:0; color:#00A660; font-size:28px;"><?php echo wc_price( $total_revenue ); ?></h2>
                    <p style="margin:6px 0 0; color:#555; font-size:13px; text-transform:uppercase; letter-spacing:.5px;">Total Revenue via Tabby</p>
                </div>

                <div style="background:#fff; border:1px solid #ddd; border-radius:8px; padding:24px; text-align:center; box-shadow:0 1px 3px rgba(0,0,0,.06);">
                    <h2 style="margin:0; color:#e67e22; font-size:28px;"><?php echo wc_price( $total_commission ); ?></h2>
                    <p style="margin:6px 0 0; color:#555; font-size:13px; text-transform:uppercase; letter-spacing:.5px;">Total Commission Collected</p>
                </div>

            </div>

            <h2>Recent Tabby Orders (last 20)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Customer</th>
                        <th>Order Total</th>
                        <th>Commission Fee</th>
                        <th>Tabby Payment ID</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $recent = wc_get_orders( [
                    'payment_method' => 'tabby_custom',
                    'limit'   => 20,
                    'orderby' => 'date',
                    'order'   => 'DESC',
                ] );
                foreach ( $recent as $order ) :
                    $commission = 0;
                    foreach ( $order->get_fees() as $fee ) {
                        if ( stripos( $fee->get_name(), 'tabby' ) !== false ) $commission += $fee->get_total();
                    }
                    $payment_id = $order->get_meta( '_tabby_payment_id' );
                ?>
                <tr>
                    <td><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_id() ); ?></a></td>
                    <td><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ); ?></td>
                    <td><?php echo wc_price( $order->get_total() ); ?></td>
                    <td><?php echo $commission > 0 ? wc_price( $commission ) : '<span style="color:#aaa;">—</span>'; ?></td>
                    <td><?php echo $payment_id ? '<code style="font-size:11px;">' . esc_html( $payment_id ) . '</code>' : '<span style="color:#aaa;">—</span>'; ?></td>
                    <td><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /** Add Tabby Fee column to orders list */
    public function add_orders_column( $columns ) {
        $new = [];
        foreach ( $columns as $key => $value ) {
            $new[ $key ] = $value;
            if ( $key === 'order_total' ) $new['tabby_commission'] = 'Tabby Fee';
        }
        return $new;
    }

    public function render_orders_column( $column, $order ) {
        if ( $column !== 'tabby_commission' ) return;
        if ( $order->get_payment_method() !== 'tabby_custom' ) { echo '<span style="color:#aaa;">—</span>'; return; }
        $commission = 0;
        foreach ( $order->get_fees() as $fee ) {
            if ( stripos( $fee->get_name(), 'tabby' ) !== false ) $commission += $fee->get_total();
        }
        echo $commission > 0 ? wc_price( $commission ) : '<span style="color:#aaa;">—</span>';
    }
}
